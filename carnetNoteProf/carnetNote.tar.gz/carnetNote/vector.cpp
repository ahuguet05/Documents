#include "vector.h"

// Constructors/Destructors
//  

vector::vector ( ) {
}

vector::~vector ( ) { }

//  
// Methods
//  



// Other methods
//  


