
#ifndef VECTOR_H
#define VECTOR_H

#include <string>
class vector
{
public:

  // Constructors/Destructors
  //  


  /**
   * Empty Constructor
   */
  vector ( );

  /**
   * Empty Destructor
   */
  virtual ~vector ( );


protected:

public:

protected:

public:

protected:


private:

public:

private:

public:

private:



};

#endif // VECTOR_H
